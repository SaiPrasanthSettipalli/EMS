package com.ems.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ems.bean.Employee;
import com.ems.bean.LeaveInfo;
import com.ems.dao.IEmployeeDao;

@Service
public class EmployeeService implements IEmployeeService{
	
	@Autowired
	IEmployeeDao iEmployeeDao;

	@Override
	public Employee checkLoginDetails(String email, String password) {
		return iEmployeeDao.checkLoginDetails(email, password);
	}

	@Override
	public List<LeaveInfo> viewEmployeeAttedance(String email) {
		
		return iEmployeeDao.viewEmployeeAttedance(email);
	}

	@Override
	public Integer viewNoOfLeaves(String email) {
		
		return iEmployeeDao.viewNoOfLeaves(email);
	}

	@Override
	public Double viewLOP(String email) {
	
		return iEmployeeDao.viewLOP(email);
	}

	@Override
	public boolean applyForTheLeave(String email, LocalDate leaveStartDate, LocalDate leaveEndDate, String Reason) {
		return iEmployeeDao.applyForTheLeave(email, leaveStartDate, leaveEndDate, Reason);
	}

	@Override
	public Employee getEmployeeDetails(String email) {
		// TODO Auto-generated method stub
		return iEmployeeDao.getEmployeeDetails(email);
	}

}
