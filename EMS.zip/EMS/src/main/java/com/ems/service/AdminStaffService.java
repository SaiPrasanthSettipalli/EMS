package com.ems.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ems.bean.AdminStaff;
import com.ems.dao.IAdminStaffDao;

@Service
public class AdminStaffService implements IAdminStaffService {
	
	
	@Autowired
	IAdminStaffDao iAdminStaffDao;

	@Override
	public AdminStaff checkLoginDetails(String userName, String password) {
		
		return iAdminStaffDao.checkLoginDetails(userName, password);
	}

	@Override
	public Boolean updateEmployeeLeaves(String email, Integer noOfLeavesToBeAdded) {
		return iAdminStaffDao.updateEmployeeLeaves(email, noOfLeavesToBeAdded);
	}

	@Override
	public Double calculateLOPS(String email) {
		return iAdminStaffDao.calculateLOPS(email);
	}

	@Override
	public boolean addDetails(AdminStaff adminStaff) {
		return iAdminStaffDao.addDetails(adminStaff);
	}
}

	