package com.ems.dao;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.ems.bean.Employee;
import com.ems.bean.LeaveInfo;
import com.ems.bean.LeaveList;

@Repository
public class EmployeeDao implements IEmployeeDao{

	@Autowired
	MongoTemplate mongoTemplate;
	
	@Override
	public Employee checkLoginDetails(String email, String password) {
		Query query=new Query();
		query.addCriteria(Criteria.where("email").is(email));
		Employee employee=mongoTemplate.findOne(query, Employee.class);
		if(employee != null) {
			if(employee.getPassword().matches(password))
				return employee;
		}
		return null;
	}
	
	@Override
	public Employee getEmployeeDetails(String email) {
		Query query=new Query();
		query.addCriteria(Criteria.where("email").is(email));
		return mongoTemplate.findOne(query, Employee.class);
	}

	@Override
	public List<LeaveInfo> viewEmployeeAttedance(String email) {
		Query query=new Query();
		query.addCriteria(Criteria.where("email").is(email));
		Employee employee=mongoTemplate.findOne(query, Employee.class);
		LeaveList leaveList=employee.getLeaveList();
		if(leaveList != null) {
			return leaveList.getLeaveInfo();
		}
		return null;	
	}
	
	@Override
	public Integer viewNoOfLeaves(String email) {
		Query query=new Query();
		query.addCriteria(Criteria.where("email").is(email));
		Employee employee=mongoTemplate.findOne(query, Employee.class);
		if(employee.getLeaveList()==null) {
			return 0;
		}
		LeaveList leaveList=employee.getLeaveList();
		return leaveList.getNoOfLeaves();
	}
	
	

	@Override
	public Double viewLOP(String email) {
		Employee employee=mongoTemplate.findById(email, Employee.class);
		if(employee.getLeaveList()==null) {
			return (double) 0;
		}
		LeaveList leaveList=employee.getLeaveList();
		Double lop;
		if(employee.getNoOfLeavesPermitted()<-5)
		{
			int noOfDaysLop=employee.getNoOfLeavesPermitted()+5;
		lop=(double) (noOfDaysLop*234.7);
		}
		else {
			lop=0.0;
		}
		leaveList.setLossOfPay(Math.abs(lop));
		employee.setLeaveList(leaveList);
		mongoTemplate.save(employee);
		return leaveList.getLossOfPay();
	}

	@Override
	public boolean applyForTheLeave(String email, LocalDate leaveStartDate,LocalDate leaveEndDate, String reason) {
		Employee employee=mongoTemplate.findById(email, Employee.class);
		if(leaveStartDate.compareTo(leaveEndDate)>0) {
			return false;
		}
		if(employee.getLeaveList()==null) {
			employee.setLeaveList(new LeaveList());	
		}
		LeaveList leaveList=employee.getLeaveList();
		if(leaveList.getLeaveInfo()==null) {
			leaveList.setLeaveInfo(new ArrayList<LeaveInfo>());
		}
		List<LeaveInfo> leaveInfos=leaveList.getLeaveInfo();
		LeaveInfo leaveInfo=new LeaveInfo();
		leaveInfo.setLeaveStartDate(leaveStartDate);
		leaveInfo.setLeaveEndDate(leaveEndDate);
		leaveInfo.setReason(reason);
		leaveInfos.add(leaveInfo);
		leaveList.setLeaveInfo(leaveInfos);
		Period duration=Period.between(leaveStartDate, leaveEndDate);
		Integer noOfLeaves=duration.getDays()+1;
		leaveList.setNoOfLeaves(leaveList.getNoOfLeaves()+noOfLeaves);
		employee.setNoOfLeavesPermitted(employee.getNoOfLeavesPermitted()-duration.getDays()-1);
		employee.setLeaveList(leaveList);
		mongoTemplate.save(employee);
		return true;
	}
}
