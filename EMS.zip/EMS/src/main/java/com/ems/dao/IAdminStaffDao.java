package com.ems.dao;

import com.ems.bean.AdminStaff;

public interface IAdminStaffDao {

	AdminStaff checkLoginDetails(String userName, String password);

	Boolean updateEmployeeLeaves(String email, Integer noOfLeavesToBeAdded);
	
	Double calculateLOPS(String email);

	boolean addDetails(AdminStaff adminStaff);
}
