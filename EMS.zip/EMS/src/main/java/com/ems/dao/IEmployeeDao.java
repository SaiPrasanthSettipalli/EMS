package com.ems.dao;

import java.time.LocalDate;
import java.util.List;

import com.ems.bean.Employee;
import com.ems.bean.LeaveInfo;

public interface IEmployeeDao {

	Employee checkLoginDetails(String email, String password);
	
	List<LeaveInfo> viewEmployeeAttedance(String email);
	
	Integer viewNoOfLeaves(String email);
	
	Double viewLOP(String email);
	
	boolean applyForTheLeave(String email, LocalDate leaveStartDate,LocalDate leaveEndDate, String Reason);

	Employee getEmployeeDetails(String email);

}