package com.ems.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.ems.bean.AdminStaff;
import com.ems.bean.Employee;
import com.ems.bean.LeaveList;

@Repository
public class AdminStaffDao implements IAdminStaffDao{

	@Autowired
	MongoTemplate mongoTemplate;
	
	@Override
	public AdminStaff checkLoginDetails(String userName, String password) {
		Query query=new Query();
		query.addCriteria(Criteria.where("userName").is(userName));
		AdminStaff adminStaff=mongoTemplate.findOne(query, AdminStaff.class);
		if(adminStaff != null) {
			if(adminStaff.getPassword().matches(password))
				return adminStaff;
		}
		return null;	
	}

	@Override
	public Boolean updateEmployeeLeaves(String email, Integer noOfLeavesToBeAdded) {
		Query query=new Query();
		query.addCriteria(Criteria.where("email").is(email));
		Employee employee=mongoTemplate.findById(email, Employee.class);
		if(employee==null) {
			return false;
		}
		Update update=new Update();
		update.set("noOfLeavesPermitted",employee.getNoOfLeavesPermitted()+noOfLeavesToBeAdded);
		mongoTemplate.updateFirst(query, update, Employee.class);
		return true;
	}

	@Override
	public Double calculateLOPS(String email) {
		Query query=new Query();
		query.addCriteria(Criteria.where("email").is(email));
		Employee employee=mongoTemplate.findById(email, Employee.class);
		if(employee==null) {
			return (double) -1;
		}
		if(employee.getLeaveList()==null) {
			return (double) 0;
		}
		LeaveList leaveList=employee.getLeaveList();
		System.out.println("lop");
		Double lop=0.0;
		if(employee.getNoOfLeavesPermitted()<-5)
		{
		lop-=(double) ((employee.getNoOfLeavesPermitted()+5)*234.7);
		leaveList.setLossOfPay(Math.abs(lop));
		employee.setLeaveList(leaveList);
		mongoTemplate.save(employee);
		System.out.println(lop);
		return lop;
		}
		return (double) 0;
	}

	@Override
	public boolean addDetails(AdminStaff adminStaff) {
		Query query=new Query();
		query.addCriteria(Criteria.where("userName").is(adminStaff.getUserName()));
		if(mongoTemplate.findOne(query, AdminStaff.class)==null)
		{
			mongoTemplate.insert(adminStaff);
			return true;
		}
		return false;
	}	
}
