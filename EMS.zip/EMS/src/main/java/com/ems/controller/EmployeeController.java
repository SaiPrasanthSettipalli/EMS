package com.ems.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ems.bean.Employee;
import com.ems.bean.LeaveInfo;
import com.ems.service.IEmployeeService;

@RestController
@RequestMapping("/employee")
@CrossOrigin(origins="http://localhost:4200")
public class EmployeeController {
	
	@Autowired
	IEmployeeService iEmployeeService;
	
	@GetMapping("/login")
	public Employee checkLoginDetails(@RequestParam String email, String password) {
		Employee employee=iEmployeeService.checkLoginDetails(email, password);
		if(employee != null)
		{
			return employee;
		}
		return null; 
	}
	
	@GetMapping("/profile")
	public Employee getEmployeeDetails(@RequestParam String email)
	{
		return iEmployeeService.getEmployeeDetails(email);
	}
	
	@GetMapping("/viewEmployeeAttendance")
	public List<LeaveInfo> viewEmployeeAttedance(@RequestParam String email){
		return iEmployeeService.viewEmployeeAttedance(email);
	}
	
	@GetMapping("/noOfLeaves")
	public Integer viewNoOfLeaves(@RequestParam String email) {
		return iEmployeeService.viewNoOfLeaves(email);
	}
	
	@GetMapping("/LOP")
	public Double viewLOP(@RequestParam String email) {
		return iEmployeeService.viewLOP(email);
	}
	
	@PostMapping("/applyforleave")
	public boolean applyForTheLeave(@RequestParam String email,String leaveStartDate,String leaveEndDate, String reason) {
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate startDate=LocalDate.parse(leaveStartDate, formatter);
		LocalDate endDate=LocalDate.parse(leaveEndDate,formatter);
		return iEmployeeService.applyForTheLeave(email,startDate, endDate, reason);
	}

}



