package com.ems.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ems.bean.AdminStaff;
import com.ems.service.IAdminStaffService;

@RestController
@RequestMapping("/adminstaff")
@CrossOrigin(origins="http://localhost:4200")
public class AdminStaffController {
	
	@Autowired
	IAdminStaffService iAdminStaffService;
	
	@GetMapping("/login")
	public AdminStaff checkLoginDetails(@RequestParam String userName, String password) {
		AdminStaff admin=iAdminStaffService.checkLoginDetails(userName, password);
		if(admin != null)
		{
			return admin;
		}
		return null;
		
	}
	
	@PostMapping("/register")
	public Boolean registerAdmin(@RequestBody AdminStaff adminStaff) {
		if(iAdminStaffService.addDetails(adminStaff))
			return true;
		return false;
	}
	
	@PostMapping("/updateEmployeeLeaves")
	public Boolean updateEmployeeLeaves(@RequestParam String email, Integer noOfLeavesToBeAdded) {
		return iAdminStaffService.updateEmployeeLeaves(email, noOfLeavesToBeAdded);
	}
	
	@GetMapping("/calculateLOPS")
	public Double calculateLOPS(@RequestParam String email) {
		return iAdminStaffService.calculateLOPS(email);
	}
	
	
	
	

}
