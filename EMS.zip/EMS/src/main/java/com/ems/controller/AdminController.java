package com.ems.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ems.bean.Admin;
import com.ems.bean.Employee;
import com.ems.service.IAdminService;


@RestController
@RequestMapping("/admin")
@CrossOrigin(origins="http://localhost:4200")
public class AdminController {
	
	@Autowired
	IAdminService iAdminService;
	
	@GetMapping("/login")
	public Admin checkLoginDetails(@RequestParam String userName, String password) {
		Admin admin=iAdminService.checkLoginDetails(userName,password);
		if(admin != null)
		{
			return admin;
		}
		return null; 
	}
	
	@PostMapping("/register")
	public Boolean registerAdmin(@RequestBody Admin admin) {
		if(iAdminService.addDetails(admin))
			return true;
		return false;
	}

	
	@GetMapping("/viewAllEmployees")
	public List<Employee> viewAllEmployees(){
		List<Employee> employeeList=iAdminService.viewEmployeeDetails();
		if(employeeList==null) {
			return null;
		}
		return employeeList;
		
	}
	
	
	@PostMapping("/addEmployee")
	public Boolean addEmployeeDetails(@RequestBody Employee employee) {
		if(employee!=null)
			return iAdminService.addEmployeeDetails(employee);
		return false;
	}
	
	@DeleteMapping("/deleteEmployee")
	Boolean deleteEmployeeDetails(@RequestParam String userName) {
		return iAdminService.deleteEmployeeDetails(userName);
	}
}
