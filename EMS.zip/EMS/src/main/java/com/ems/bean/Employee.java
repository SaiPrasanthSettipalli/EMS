package com.ems.bean;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Employee {

	private String employeeName;
	@Id
	private String email;
	private String password;
	private LeaveList leaveList;
	private String birthDate;
	private String address;
	private Integer noOfLeavesPermitted;
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public LeaveList getLeaveList() {
		return leaveList;
	}
	public void setLeaveList(LeaveList leaveList) {
		this.leaveList = leaveList;
	}
	public String getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Integer getNoOfLeavesPermitted() {
		return noOfLeavesPermitted;
	}
	public void setNoOfLeavesPermitted(Integer noOfLeavesPermitted) {
		this.noOfLeavesPermitted = noOfLeavesPermitted;
	}
	public Employee(String employeeName, String email, String password, LeaveList leaveList, String birthDate,
			String address, Integer noOfLeavesPermitted) {
		super();
		this.employeeName = employeeName;
		this.email = email;
		this.password = password;
		this.leaveList = leaveList;
		this.birthDate = birthDate;
		this.address = address;
		this.noOfLeavesPermitted = noOfLeavesPermitted;
	}
	
}
